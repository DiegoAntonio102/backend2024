const mensaje = "Hola Mundo"
const otromensaje = "Este es otro mensaje"

console.log(mensaje)

if(mensaje){
    console.log("Se imprimio el mensaje")
}

module.exports = {otromensaje}
