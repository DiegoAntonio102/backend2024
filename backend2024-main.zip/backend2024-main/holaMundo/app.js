//import { otromensaje } from "./hola"; //exportación por defecto
const {otromensaje} = require("./hola")

console.log("Este es el punto de entrada")
console.log(otromensaje)
